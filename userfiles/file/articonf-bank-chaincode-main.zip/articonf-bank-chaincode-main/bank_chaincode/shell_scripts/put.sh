#!/bin/bash
set -x #echo on

export CORE_PEER_ADDRESS="peer2:7051"
export CORE_PEER_MSPCONFIGPATH="/root/admin/msp"
export CORE_PEER_TLS_ROOTCERT_FILE="/root/${PEER2_HOST}/tls-msp/tlscacerts/tls-${TLSCA_HOST}-7054.pem"
export CORE_PEER_ADDRESS=$CORE_PEER_ADDRESS
export CORE_PEER_MSPCONFIGPATH=$CORE_PEER_MSPCONFIGPATH
export CORE_PEER_TLS_ROOTCERT_FILE=$CORE_PEER_TLS_ROOTCERT_FILE


#peer chaincode invoke -C appchannel -n bankcccccc -c '{"Args":["initMarble","marble1","blue","35","tom","1000"]}' --tls --cafile ${CORE_PEER_TLS_ROOTCERT_FILE} &&
#peer chaincode invoke -C appchannel -n bankcccccc -c '{"Args":["initMarble","marble2","green","35","tom","1000"]}' --tls --cafile ${CORE_PEER_TLS_ROOTCERT_FILE}
peer chaincode invoke -C appchannel -n bankcccccc -c '{"Args":["buy_bank","marble1","marble2","45"]}' --tls --cafile ${CORE_PEER_TLS_ROOTCERT_FILE}
